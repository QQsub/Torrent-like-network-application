import socket
import json
import hashlib
import os
import threading
import time
import bencodepy
from urllib.parse import urlparse

# Configuration section
PEER_DOWNLOAD_DIR = "Torrent-like-network-application/Client_repos"  # Directory of client
TRACKER_IP = '192.168.77.147'  # Tracker IP address
TRACKER_PORT = 12340  # Tracker Port
PEER_PORT = 12341 # Peer port for download/upload
PEER_ID = "peer_1"  # Unique peer ID for this client
PIECE_LENGTH = 512 * 1024  # Default piece length (512 KB)
RETRY_COUNT = 3  # Number of retries for downloading a piece
TRACKER_ID = None
COMPACT_FLAGS = False
#Node db directory
directory_path = r'C:\Users\Administrator\Desktop\Assignment\Torrent-like-network-application\Node_repos\ClientDB'
# Create directory to store downloaded pieces and state
# os.makedirs(PEER_DOWNLOAD_DIR, exist_ok=True)

# Function to announce to tracker and get peer list
def announce_to_tracker(file_name = None, event="started"):
    global TRACKER_ID
    try:
        if not file_name:
            raise ValueError("File name missing or not available")
        tracker_ip = TRACKER_IP
        tracker_port = TRACKER_PORT

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as tracker_socket:
            tracker_socket.connect((tracker_ip, int(tracker_port)))
            request = {
                "announce": "Peer to tracker",
                "file_name": file_name,
                "peer_id": PEER_ID,  # Use the global peer ID
                "port": PEER_PORT,
                "event": event,
                "tracker_id": None,
                "available_pieces": load_available_pieces() or [],  # Send available pieces to tracker
                "downloaded_pieces": load_downloaded_pieces() or [],
                "uploaded_pieces": load_uploaded_pieces() or [],
                "compact": COMPACT_FLAGS
            }

            # Include the tracker ID if available
            if TRACKER_ID is not None:
                request["tracker_id"] = TRACKER_ID

            print(request)
            tracker_socket.sendall(json.dumps(request).encode("utf-8"))
            response = tracker_socket.recv(4096).decode("utf-8")
            response_data = json.loads(response)

            # Save tracker ID if present
            if "tracker id" in response_data:
                TRACKER_ID = response_data["tracker id"]

            # Log warning message if present
            if "warning message" in response_data:
                print(f"Warning from tracker: {response_data['warning message']}")

            return response_data

    except Exception as e:
        print(f"Error announcing to tracker: {e}")
        return None

# Function to load the available pieces from the local repository
def load_available_pieces():
    return []
def load_downloaded_pieces():
    return []
def load_uploaded_pieces():
    return []

# def load_available_pieces(metainfo): 
#     # Get all file names in the directory
#     try:
#         files_in_directory = os.listdir(directory_path)
#     except FileNotFoundError:
#         print("Directory not found.")
#         return []
#     except PermissionError:
#         print("Permission denied to access the directory.")
#         return [] 
#     # Extract pieces (infohashes) from metainfo
#     infohashes = set(metainfo.get('pieces', []))
#     # Compare file names with infohashes and collect matches
#     available_pieces = [file for file in files_in_directory if file in infohashes]
#     return available_pieces


# Function to download a piece from a peer
def download_piece(peer, info_hash, piece_index, piece_length, retries=RETRY_COUNT):
    for attempt in range(retries):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as peer_socket:
                peer_socket.connect((peer["ip"], peer["port"]))
                request = {
                    "type": "piece_request",
                    "info_hash": info_hash,
                    "piece_index": piece_index,
                }
                peer_socket.sendall(json.dumps(request).encode("utf-8"))
                response = peer_socket.recv(4096)
                data = json.loads(response.decode("utf-8"))
                if data["status"] == "success":
                    return data["data"]
        except Exception as e:
            print(f"Error downloading piece {piece_index} from {peer['ip']} (attempt {attempt + 1}): {e}")
        time.sleep(1)  # Retry delay
    print(f"Failed to download piece {piece_index} after {retries} retries.")
    return None

# Verify the hash of a piece
def verify_piece(data, expected_hash):
    actual_hash = hashlib.sha1(data).hexdigest()
    return actual_hash == expected_hash

# Save the state of downloaded pieces
def save_download_state(info_hash, downloaded_pieces):
    state_file = f"{PEER_DOWNLOAD_DIR}/{info_hash}_state.json"
    with open(state_file, "w") as f:
        json.dump({"downloaded_pieces": downloaded_pieces}, f)

# Load the state of downloaded pieces
def load_download_state(info_hash):
    state_file = f"{PEER_DOWNLOAD_DIR}/{info_hash}_state.json"
    if os.path.exists(state_file):
        with open(state_file, "r") as f:
            return json.load(f).get("downloaded_pieces", [])
    return []

# Find the rarest pieces
def find_rarest_pieces(peers, total_pieces):
    piece_counts = [0] * total_pieces
    for peer in peers:
        for piece in peer.get("available_pieces", []):
            piece_counts[piece] += 1
    return sorted(range(total_pieces), key=lambda x: piece_counts[x])

# Serve uploaded pieces to other peers
def serve_upload_requests(info_hash):
    def handle_peer_connection(conn):
        try:
            data = conn.recv(4096).decode("utf-8")
            request = json.loads(data)
            if request["type"] == "piece_request" and request["info_hash"] == info_hash:
                piece_index = request["piece_index"]
                piece_path = f"{PEER_DOWNLOAD_DIR}/{info_hash}_pieces/{piece_index}"
                if os.path.exists(piece_path):
                    with open(piece_path, "rb") as piece_file:
                        response = {"status": "success", "data": piece_file.read()}
                else:
                    response = {"status": "error", "message": "Piece not found"}
                conn.sendall(json.dumps(response).encode("utf-8"))
        except Exception as e:
            print(f"Error handling peer connection: {e}")
        finally:
            conn.close()

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", PEER_PORT))  # Bind to a local port
    server.listen(5)
    print("Peer-to-peer upload server started. Seeding...")

    try:
        while True:
            conn, addr = server.accept()
            threading.Thread(target=handle_peer_connection, args=(conn,)).start()
    except KeyboardInterrupt:
        print("Seeding stopped by user.")
    finally:
        server.close()

# Seeding Loop
def start_seeding(metainfo):
    print("Seeding started...")
    try:
        while True:
            response = announce_to_tracker(metainfo, event="completed")
            if response and "failure reason" not in response:
                print("Seeding in progress... Announced to tracker.")
            else:
                print("Tracker announce failed during seeding.")
            time.sleep(30)  # Re-announce to tracker every 30 seconds
    except KeyboardInterrupt:
        announce_to_tracker(metainfo, event="stopped")
        print("Seeding terminated by user.")

# Extract metadata for a specific file in a multi-file torrent.
def get_file_metadata(metadata, file_name):
    for file_info in metadata["files"]:
        if file_info["path"] == file_name:
            return file_info
    return None

 # Calculate the range of pieces that contain the requested file.
def get_file_piece_indices(metadata, file_metadata):
    piece_length = metadata["piece_length"]
    start_offset = 0

    # Calculate the starting byte offset for the file
    for f in metadata["files"]:
        if f["path"] == file_metadata["path"]:
            break
        start_offset += f["length"]

    end_offset = start_offset + file_metadata["length"]

    # Calculate start and end piece indices
    start_piece = start_offset // piece_length
    end_piece = (end_offset + piece_length - 1) // piece_length  # Inclusive range

    return list(range(start_piece, end_piece))


# Merge specific files
def merge_pieces_for_file(metadata, file_metadata, pieces_dir, output_file):
    # Combine pieces to reconstruct the requested file.
    piece_length = metadata["piece_length"]
    file_length = file_metadata["length"]
    start_offset = 0

    # Calculate the starting byte offset for the file
    for f in metadata["files"]:
        if f["path"] == file_metadata["path"]:
            break
        start_offset += f["length"]

    end_offset = start_offset + file_length
    start_piece = start_offset // piece_length
    end_piece = (end_offset + piece_length - 1) // piece_length

    with open(output_file, 'wb') as output:
        for piece_index in range(start_piece, end_piece):
            piece_path = os.path.join(pieces_dir, f"piece_{piece_index}")
            with open(piece_path, 'rb') as piece_file:
                piece_data = piece_file.read()

                # Calculate start and end bytes for this piece
                piece_start = max(0, start_offset - (piece_index * piece_length))
                piece_end = min(piece_length, end_offset - (piece_index * piece_length))

                # Write the relevant portion to the output file
                output.write(piece_data[piece_start:piece_end])

    print(f"File successfully reconstructed: {output_file}")

# Download the torrent
def download_from_torrent(file_name, response):
    if not response or "failure reason" in response:
        print(f"Failed to announce to tracker: {response.get('failure reason')}")
        return

    metadata = response["metadata"]
    peers = response["peers"]
    pieces_dir = f"{PEER_DOWNLOAD_DIR}/{metadata['info_hash']}_pieces"
    os.makedirs(pieces_dir, exist_ok=True)

    # Get metadata for the requested file
    file_metadata = get_file_metadata(metadata, file_name)
    if not file_metadata:
        print(f"File '{file_name}' not found in torrent metadata.")
        return

    # Calculate piece indices for the requested file
    file_piece_indices = get_file_piece_indices(metadata, file_metadata)
    print(f"File '{file_name}' spans pieces: {file_piece_indices}")

    # Check existing pieces
    existing_pieces = check_existing_pieces(metadata, pieces_dir)
    relevant_existing_pieces = set(existing_pieces).intersection(file_piece_indices)
    print(f"Existing pieces for '{file_name}': {len(relevant_existing_pieces)}/{len(file_piece_indices)}")

    # If all pieces are available, merge the file
    if len(relevant_existing_pieces) == len(file_piece_indices):
        print(f"All pieces for '{file_name}' are already downloaded. Merging...")
        merge_pieces_for_file(metadata, file_metadata, pieces_dir, file_name)
        return

    # Identify missing pieces
    missing_pieces = list(set(file_piece_indices) - relevant_existing_pieces)
    print(f"Missing pieces for '{file_name}': {missing_pieces}")

    # Download missing pieces
    for piece_index in missing_pieces:
        for peer in peers:
            if piece_index in peer["available_pieces"]:
                if download_piece(piece_index, peer, metadata, pieces_dir):
                    relevant_existing_pieces.add(piece_index)
                    break

    # Merge the file if all pieces are downloaded
    if len(relevant_existing_pieces) == len(file_piece_indices):
        merge_pieces_for_file(metadata, file_metadata, pieces_dir, file_name)
    else:
        print(f"Download incomplete for '{file_name}'. Missing pieces remain.")

def choose_file():
    while True:
        print("Which file are you interested in:")
        print("1. random_2MB.txt")
        print("2. random_3MB.txt")
        print("3. random_4MB.txt")
        choice = input("Choose an option: ")
        if choice == "1":
            return "random_2MB.txt"   
        elif choice == "2":
            return "random_4MB.txt"
        elif choice == "3":
            return "random_8MB.txt"   
        else:
            print("Invalid option. Please choose 1, 2 or 3.")
            continue
    return ""

def choose_option():
    while True:
        print("What do you want to do")
        print("1. Download from others")
        print("2. Upload to others")
        print("3. Stop and exit from network")
        choice = input("Choose an option: ")
        if choice == "1":
            return "Download"  
        elif choice == "2":
            return "Upload"
        elif choice == "3":
            return "Exit"
        else:
            print("Invalid option. Please choose 1, 2 or 3.")
            continue
    return ""

# Example usage
if __name__ == "__main__":
    print("Welcome to the network")
    connected = False
    while True:
        option = choose_option()
        if option != "Exit":
            file_name = choose_file()       
        if option == "Download":
            connected = True
            response = announce_to_tracker(file_name, event="download")
            download_from_torrent(file_name, response)
        elif option == "Upload":
            connected = True
            response = announce_to_tracker(file_name, event ="upload")
            download_from_torrent(file_name, response)
        elif option == "Exit":
            if connected == True:
                response = announce_to_tracker(file_name, event = "stopped")
                download_from_torrent(file_name, response)
            break


    
